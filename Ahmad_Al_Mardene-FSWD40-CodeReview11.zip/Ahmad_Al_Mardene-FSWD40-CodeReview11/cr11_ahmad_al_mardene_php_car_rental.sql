-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 10:40 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cr11_ahmad_al_mardene_php_car_rental`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` int(11) NOT NULL,
  `street` varchar(100) DEFAULT NULL,
  `zip_code` int(6) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`address_id`, `street`, `zip_code`, `country`, `city`) VALUES
(1, 'längenfeldgasse 13-15', 1120, 'Österreich', 'wien'),
(2, 'Linzerstraße 63', 1140, 'Österreich', 'wien'),
(3, 'Absengerstraße', 8052, 'Österreich', 'graz'),
(4, 'Bahnhofplatz 1', 4021, 'Österreich', 'linz');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `carId` int(11) NOT NULL,
  `brand` varchar(55) DEFAULT NULL,
  `model` varchar(55) DEFAULT NULL,
  `fk_officeId` int(11) DEFAULT NULL,
  `carNum` int(11) DEFAULT NULL,
  `location` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`carId`, `brand`, `model`, `fk_officeId`, `carNum`, `location`) VALUES
(1, 'Volvo', 'c70', 1, 121212, NULL),
(2, 'SEAT', 'IBIZA', 1, 131313, NULL),
(3, 'BMW', '316', 1, 21222, NULL),
(4, 'BMW', '530', 1, 31333, NULL),
(5, 'Opel', 'Zafira', 2, 221222, NULL),
(6, 'Reunault', 'Transporter', 2, 331333, NULL),
(7, 'Chevrolet', 'Challenger', 2, 772277, NULL),
(8, 'BMW', '350', 3, 227722, NULL),
(9, 'BMW', '318', 3, 954547, NULL),
(10, 'SEAT', 'LION', 3, 101054, NULL),
(11, 'Mercedes', 'C300', 4, 1116548, NULL),
(12, 'Porsche', 'Carrira', 4, 1255487, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customerId` int(11) NOT NULL,
  `name` varchar(55) DEFAULT NULL,
  `surname` varchar(55) DEFAULT NULL,
  `licenceNum` int(11) DEFAULT NULL,
  `fk_carId` int(11) DEFAULT NULL,
  `location` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerId`, `name`, `surname`, `licenceNum`, `fk_carId`, `location`) VALUES
(1, 'Norbert', 'Payer', 1121121, 1, 'hauptbahnhof');

-- --------------------------------------------------------

--
-- Table structure for table `offices`
--

CREATE TABLE `offices` (
  `officeId` int(11) NOT NULL,
  `address` varchar(250) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `offices`
--

INSERT INTO `offices` (`officeId`, `address`, `phone`) VALUES
(1, '1120 Vienna, Meidling Hauptstrasse 14', '0999313985'),
(2, '1100 Vienna, laaer-Berg_Strasse 39', '0932745555'),
(3, '1040 Vienna, Favoritenstrasse 17', '0796655124'),
(4, '1060 Vienna, Fritz-Grünbaum-Platz 1', '0942255478');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `userEmail` varchar(50) DEFAULT NULL,
  `userPass` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userPass`) VALUES
(0, 'ahmad', 'ahmad.yoness@gmail.com', 'e429ad3e7391ebaa11bdfd8414e73477092f25403edc94ff9485306c25e180ec');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`carId`),
  ADD KEY `fk_officeId` (`fk_officeId`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerId`),
  ADD KEY `fk_carId` (`fk_carId`);

--
-- Indexes for table `offices`
--
ALTER TABLE `offices`
  ADD PRIMARY KEY (`officeId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cars`
--
ALTER TABLE `cars`
  ADD CONSTRAINT `cars_ibfk_1` FOREIGN KEY (`fk_officeId`) REFERENCES `offices` (`officeId`);

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`fk_carId`) REFERENCES `cars` (`carId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
